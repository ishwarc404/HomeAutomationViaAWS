Downloaded from: https://github.com/rhempel/c-helper-macros/tree/develop
